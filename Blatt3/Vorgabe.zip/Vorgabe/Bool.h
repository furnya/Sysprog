#include <stdint.h>

#ifndef BOOL_H
#define BOOL_H

#define bool uint8_t
#define true 1
#define false 0

#define SUCCESS 1;
#define FAILURE 0;

#endif
