#include "FCFS.h"

void schedule_FCFS(const TaskPool *task_pool) {
    // TODO
    printf("NOT IMPLEMENTED!\n");
}
