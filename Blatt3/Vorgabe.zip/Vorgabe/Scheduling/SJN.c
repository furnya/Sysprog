#include "SJN.h"

void schedule_SJN(const TaskPool *task_pool) {
    // TODO
    printf("NOT IMPLEMENTED!\n");
}
