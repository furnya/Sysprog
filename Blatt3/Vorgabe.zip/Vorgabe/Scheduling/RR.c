#include "RR.h"

void schedule_RR(const TaskPool *task_pool, uint16_t quantum_max) {
    // TODO
    printf("NOT IMPLEMENTED!\n");
}
