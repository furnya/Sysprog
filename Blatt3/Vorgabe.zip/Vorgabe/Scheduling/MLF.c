#include "MLF.h"

void schedule_MLF(const TaskPool *task_pool, uint16_t num_levels) {
    // TODO
    printf("NOT IMPLEMENTED!\n");
}
